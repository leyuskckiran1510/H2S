from h2s import Har


harFile = "./HAR_FILE.har"

x = Har(harFile)
print(x)


